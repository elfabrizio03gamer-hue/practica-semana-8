package pe.edu.ferreteria.pattern;

import pe.edu.ferreteria.model.Pago;

public class PagoAdapter extends Pago {
    private final PasarelaExterna pasarelaExterna;
    private final String numeroTarjeta;

    public PagoAdapter(String id, double monto, String numeroTarjeta) {
        super(id, monto, "TARJETA_EXTERNA", "PENDIENTE");
        this.pasarelaExterna = new PasarelaExterna();
        this.numeroTarjeta = numeroTarjeta;
    }

    public boolean procesarPagoAdapter() {
        boolean exito = pasarelaExterna.realizarCobroTarjeta(numeroTarjeta, getMonto());
        if (exito) {
            setEstado("APROBADO");
        } else {
            setEstado("RECHAZADO");
        }
        return exito;
    }
}
