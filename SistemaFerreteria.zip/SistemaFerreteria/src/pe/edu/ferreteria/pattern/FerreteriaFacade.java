package pe.edu.ferreteria.pattern;

import pe.edu.ferreteria.model.*;
import pe.edu.ferreteria.service.Inventario;

public class FerreteriaFacade {
    private final Inventario inventario;

    public FerreteriaFacade(Inventario inventario) {
        this.inventario = inventario;
    }

    public void registrarVentaCompleta(Cliente cliente, Producto producto, int cantidad, String numeroTarjeta) {
        System.out.println("\n--- INICIando PROCESO DE VENTA (FAÇADE) ---");

        // 1. Verificar stock
        if (!inventario.hayStock(producto.getCodigo(), cantidad)) {
            System.out.println("Error: No hay stock suficiente para " + producto.getNombre());
            return;
        }

        // 2. Retirar stock
        inventario.retirar(producto.getCodigo(), cantidad);

        // 3. Crear venta y detalle
        Venta venta = new Venta(101, cliente);
        venta.agregarProducto(producto);

        // 4. Procesar pago usando el Adapter
        double total = venta.calcularTotal() * cantidad;
        PagoAdapter pagoAdapter = new PagoAdapter("PAG-001", total, numeroTarjeta);
        pagoAdapter.procesarPagoAdapter();

        // 5. Emitir comprobante
        if (pagoAdapter.estaAprobado()) {
            Comprobante comprobante = new Comprobante("B001-0001", "BOLETA", total);
            System.out.println("¡Venta exitosa!");
            System.out.println("Cliente: " + cliente.getNombre());
            System.out.println("Comprobante: " + comprobante.getTipo() + " " + comprobante.getNumero());
            System.out.println("Monto Pagado: S/" + String.format("%.2f", comprobante.getTotal()));
            System.out.println("Stock restante de " + producto.getNombre() + ": " + inventario.consultarStock(producto.getCodigo()));
        } else {
            System.out.println("El pago fue rechazado.");
        }
    }
}
