package pe.edu.ferreteria.pattern;

public class PasarelaExterna {
    public boolean realizarCobroTarjeta(String numeroTarjeta, double montoTotal) {
        System.out.println("[Pasarela Externa] Cobrando S/" + montoTotal + " a la tarjeta " + numeroTarjeta);
        return true; // Simula éxito en el pago externo
    }
}