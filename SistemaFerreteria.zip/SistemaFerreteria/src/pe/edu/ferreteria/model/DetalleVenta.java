package pe.edu.ferreteria.model;

public class DetalleVenta {
    private final Producto producto;
    private final int cantidad;
    private final double precioUnitario;

    public DetalleVenta(Producto producto, int cantidad, double precioUnitario) {
        if (producto == null) throw new IllegalArgumentException("Producto requerido");
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad debe ser mayor a cero");
        this.producto = producto;
        this.cantidad = cantidad;
        this.precioUnitario = precioUnitario;
    }

    public double subtotal() {
        return cantidad * precioUnitario;
    }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getPrecioUnitario() { return precioUnitario; }
}