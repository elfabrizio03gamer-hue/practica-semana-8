package pe.edu.ferreteria.model;

public class Proveedor {
    private final String codigo;
    private final String ruc;
    private final String razonSocial;
    private boolean activo;

    public Proveedor(String codigo, String ruc, String razonSocial, boolean activo) {
        this.codigo = codigo;
        this.ruc = ruc;
        this.razonSocial = razonSocial;
        this.activo = activo;
    }

    public String getCodigo() { return codigo; }
    public String getRuc() { return ruc; }
    public String getRazonSocial() { return razonSocial; }
    public boolean isActivo() { return activo; }
    public void setActivo(boolean activo) { this.activo = activo; }
}
