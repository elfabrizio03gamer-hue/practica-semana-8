package pe.edu.ferreteria.model;

public class Pago {
    private final String id;
    private final double monto;
    private final String medio;
    private String estado;

    public Pago(String id, double monto, String medio, String estado) {
        this.id = id;
        this.monto = monto;
        this.medio = medio;
        this.estado = estado;
    }

    public boolean estaAprobado() {
        return "APROBADO".equalsIgnoreCase(estado);
    }

    public String getId() { return id; }
    public double getMonto() { return monto; }
    public String getMedio() { return medio; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
}
