package pe.edu.ferreteria.model;

public class DetallePedidoCompra {
    private final Producto producto;
    private final int cantidad;
    private final double costoUnitario;

    public DetallePedidoCompra(Producto producto, int cantidad, double costoUnitario) {
        this.producto = producto;
        this.cantidad = cantidad;
        this.costoUnitario = costoUnitario;
    }

    public double subtotal() {
        return cantidad * costoUnitario;
    }

    public Producto getProducto() { return producto; }
    public int getCantidad() { return cantidad; }
    public double getCostoUnitario() { return costoUnitario; }
}
