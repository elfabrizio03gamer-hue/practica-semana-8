package pe.edu.ferreteria.model;

public class Categoria {
    private final String id;
    private final String nombre;
    private final String descripcion;

    public Categoria(String id, String nombre, String descripcion) {
        if (id == null || id.isBlank()) throw new IllegalArgumentException("ID requerido");
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Nombre requerido");
        this.id = id;
        this.nombre = nombre;
        this.descripcion = descripcion;
    }

    public String getId() { return id; }
    public String getNombre() { return nombre; }
    public String getDescripcion() { return descripcion; }
}