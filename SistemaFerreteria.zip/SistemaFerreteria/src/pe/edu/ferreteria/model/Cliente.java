package pe.edu.ferreteria.model;

public class Cliente {
    private final String documento;
    private final String nombre;

    public Cliente(String documento, String nombre) {
        if (documento == null || documento.isBlank()) throw new IllegalArgumentException("Documento requerido");
        if (nombre == null || nombre.isBlank()) throw new IllegalArgumentException("Nombre requerido");
        this.documento = documento;
        this.nombre = nombre;
    }

    public String getDocumento() { return documento; }
    public String getNombre() { return nombre; }

    @Override
    public String toString() {
        return documento + " - " + nombre;
    }
}
