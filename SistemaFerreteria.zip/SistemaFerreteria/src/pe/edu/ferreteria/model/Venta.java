package pe.edu.ferreteria.model;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class Venta {
    private final int id;
    private final Cliente cliente;
    private final List<Producto> productos = new ArrayList<>();

    public Venta(int id, Cliente cliente) {
        this.id = id;
        this.cliente = cliente;
    }

    public void agregarProducto(Producto producto) {
        if (producto == null) throw new IllegalArgumentException("Producto requerido");
        productos.add(producto);
    }

    public double calcularTotal() {
        return productos.stream().mapToDouble(Producto::getPrecio).sum();
    }

    public int getId() { return id; }
    public Cliente getCliente() { return cliente; }
    public List<Producto> getProductos() { return Collections.unmodifiableList(productos); }
}