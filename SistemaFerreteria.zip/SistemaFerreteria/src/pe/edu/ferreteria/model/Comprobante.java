package pe.edu.ferreteria.model;

import java.time.LocalDate;

public class Comprobante {
    private final String numero;
    private final String tipo;
    private final LocalDate fecha;
    private final double total;

    public Comprobante(String numero, String tipo, double total) {
        this.numero = numero;
        this.tipo = tipo;
        this.fecha = LocalDate.now();
        this.total = total;
    }

    public String getNumero() { return numero; }
    public String getTipo() { return tipo; }
    public LocalDate getFecha() { return fecha; }
    public double getTotal() { return total; }
}