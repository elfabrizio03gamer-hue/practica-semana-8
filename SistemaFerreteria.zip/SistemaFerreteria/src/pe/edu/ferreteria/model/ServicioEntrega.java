package pe.edu.ferreteria.model;

public class ServicioEntrega {
    private final String id;
    private final String direccion;
    private final double costo;
    private String estado; // "PROGRAMADO", "DESPACHADO", "ENTREGADO"

    public ServicioEntrega(String id, String direccion, double costo) {
        this.id = id;
        this.direccion = direccion;
        this.costo = costo;
        this.estado = "PROGRAMADO";
    }

    public void marcarDespachado() { this.estado = "DESPACHADO"; }
    public void marcarEntregado() { this.estado = "ENTREGADO"; }

    public String getId() { return id; }
    public String getDireccion() { return direccion; }
    public double getCosto() { return costo; }
    public String getEstado() { return estado; }
}