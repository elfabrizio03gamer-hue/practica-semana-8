package pe.edu.ferreteria.model;

import java.util.ArrayList;
import java.util.List;

public class PedidoCompra {
    private final int id;
    private final Proveedor proveedor;
    private String estado;
    private final List<DetallePedidoCompra> detalles = new ArrayList<>();

    public PedidoCompra(int id, Proveedor proveedor) {
        this.id = id;
        this.proveedor = proveedor;
        this.estado = "PENDIENTE";
    }

    public void agregarDetalle(DetallePedidoCompra detalle) {
        detalles.add(detalle);
    }

    public double calcularTotal() {
        return detalles.stream().mapToDouble(DetallePedidoCompra::subtotal).sum();
    }

    public int getId() { return id; }
    public Proveedor getProveedor() { return proveedor; }
    public String getEstado() { return estado; }
    public void setEstado(String estado) { this.estado = estado; }
    public List<DetallePedidoCompra> getDetalles() { return detalles; }
}