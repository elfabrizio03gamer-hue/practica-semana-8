package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.Producto;
import java.util.HashMap;
import java.util.Map;

public class Inventario {
    private final Map<String, Producto> productos = new HashMap<>();
    private final Map<String, Integer> stock = new HashMap<>();

    public void registrarProducto(Producto producto, int cantidadInicial) {
        if (cantidadInicial < 0) throw new IllegalArgumentException("Stock inválido");
        productos.put(producto.getCodigo(), producto);
        stock.put(producto.getCodigo(), cantidadInicial);
    }

    public Producto buscar(String codigo) {
        return productos.get(codigo);
    }

    public int consultarStock(String codigo) {
        return stock.getOrDefault(codigo, 0);
    }

    public boolean hayStock(String codigo, int cantidad) {
        return cantidad > 0 && consultarStock(codigo) >= cantidad;
    }

    public void retirar(String codigo, int cantidad) {
        if (!hayStock(codigo, cantidad)) throw new IllegalStateException("Stock insuficiente");
        stock.put(codigo, consultarStock(codigo) - cantidad);
    }

    public void ingresar(String codigo, int cantidad) {
        if (!productos.containsKey(codigo)) throw new IllegalArgumentException("Producto no registrado");
        if (cantidad <= 0) throw new IllegalArgumentException("Cantidad inválida");
        stock.put(codigo, consultarStock(codigo) + cantidad);
    }
}
