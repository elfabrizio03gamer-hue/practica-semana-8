package pe.edu.ferreteria.service;

import pe.edu.ferreteria.model.Venta;
import java.util.List;

public class ReporteVentas {
    public void generarReporte(List<Venta> ventas) {
        double totalVendido = ventas.stream().mapToDouble(Venta::calcularTotal).sum();
        int numeroVentas = ventas.size();
        double ticketPromedio = numeroVentas > 0 ? totalVendido / numeroVentas : 0.0;

        System.out.println("=== REPORTE DE VENTAS ===");
        System.out.println("Total vendido: S/" + String.format("%.2f", totalVendido));
        System.out.println("Número de ventas: " + numeroVentas);
        System.out.println("Ticket promedio: S/" + String.format("%.2f", ticketPromedio));
    }
}