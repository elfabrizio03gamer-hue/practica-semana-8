package pe.edu.ferreteria.app;

import pe.edu.ferreteria.model.Cliente;
import pe.edu.ferreteria.model.Producto;
import pe.edu.ferreteria.pattern.FerreteriaFacade;
import pe.edu.ferreteria.service.Inventario;

public class FerreteriaApp {
    public static void main(String[] args) {
        Inventario inventario = new Inventario();

        Producto amoladora = new Producto("P-300", "Amoladora Angular", 189.90);
        inventario.registrarProducto(amoladora, 8);

        Cliente cliente = new Cliente("72145896", "Carlos Mendoza");

        // Usamos la Fachada para gestionar toda la venta compleja de forma limpia
        FerreteriaFacade fachada = new FerreteriaFacade(inventario);
        fachada.registrarVentaCompleta(cliente, amoladora, 2, "4555-****-****-1234");
    }
}
